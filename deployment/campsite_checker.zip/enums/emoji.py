from enum import Enum


class Emoji(Enum):
    SUCCESS = "🏕"
    FAILURE = "❌"
